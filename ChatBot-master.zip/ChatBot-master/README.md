# ChatBot
This is a chatbot created using Dialogflow and Node js
## Installation
download Node.js installer from browser and install it through Node.js setup wizard
verify installation using:
```bash
node -v
```
or use
```bash
npm -v
```

install dialogflow client library using the folowing command
```bash
npm install dialogflow
```

run the app using the follwing command:
```bash
npm app
```
